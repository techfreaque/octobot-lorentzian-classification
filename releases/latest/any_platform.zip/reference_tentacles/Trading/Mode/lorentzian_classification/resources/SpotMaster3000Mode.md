SpotMaster3000Mode allows you to automatically balance your portfolio. 
Get a resilient portfolio and benefit from asset price differences