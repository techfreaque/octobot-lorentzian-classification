Lorentzian classification evaluator, based on the trading view indicator from jdehorty and ported to OctoBot by Max https://github.com/techfreaque 
