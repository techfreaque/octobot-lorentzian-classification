import enum


class SpotMasterOrderTypes(enum.Enum):
    MARKET = "Market Orders"
    LIMIT = "Limit Orders"
