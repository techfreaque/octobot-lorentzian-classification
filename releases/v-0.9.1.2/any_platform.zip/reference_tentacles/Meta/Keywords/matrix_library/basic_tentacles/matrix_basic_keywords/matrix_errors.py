class MaximumOpenPositionReachedError(Exception):
    pass
