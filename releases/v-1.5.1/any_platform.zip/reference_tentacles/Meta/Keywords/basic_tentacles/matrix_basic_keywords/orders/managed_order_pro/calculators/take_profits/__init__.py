from .based_on_indicator import *
from .based_on_static_price import *
from .based_on_risk_reward import *
from .based_on_percent import *
